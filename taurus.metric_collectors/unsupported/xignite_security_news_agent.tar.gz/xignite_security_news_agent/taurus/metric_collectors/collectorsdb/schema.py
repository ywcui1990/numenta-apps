# ----------------------------------------------------------------------
# Numenta Platform for Intelligent Computing (NuPIC)
# Copyright (C) 2015, Numenta, Inc.  Unless you have purchased from
# Numenta, Inc. a separate commercial license for this software code, the
# following terms and conditions apply:
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero Public License version 3 as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU Affero Public License for more details.
#
# You should have received a copy of the GNU Affero Public License
# along with this program.  If not, see http://www.gnu.org/licenses.
#
# http://numenta.org/licenses/
# ----------------------------------------------------------------------

"""Common SQLAlchemy table definitions for metric collectors."""

import sqlalchemy as sa
from sqlalchemy import (BOOLEAN,
                        Column,
                        DATE,
                        DATETIME,
                        FLOAT,
                        ForeignKey,
                        ForeignKeyConstraint,
                        func,
                        Index,
                        INTEGER,
                        MetaData,
                        PrimaryKeyConstraint,
                        Table,
                        TEXT,
                        TIME,
                        TIMESTAMP)

from sqlalchemy.dialects import mysql


# utf8mb4 is needed for successful handling of multi-byte unicode (e.g., some
# emoticons), but is only supported by mysql-v5.5.3+
# NOTE: CHARSET utf8mb4 together with COLLATE utf8mb4_unicode_ci appears to work
# fine with datasift and twitter interaction data. However, the metric collector
# server that we're using at this time is stuck at mysql-v5.1.x, so we can't
# make use of utf8mb4 yet!!!
#MYSQL_CHARSET = "utf8mb4"
MYSQL_CHARSET = "utf8"
MYSQL_COLLATE = MYSQL_CHARSET + "_unicode_ci"

# 190 facilitates utf8mb4 ("max key length is 767 bytes")
MAX_UTF8_KEY_LENGTH=190

METRIC_NAME_MAX_LEN=MAX_UTF8_KEY_LENGTH


metadata = MetaData()


def _createXigniteGlobalnewsSchema(schemaName, metadata):
  schema = Table(
    schemaName,
    metadata,

    # Foreign key reference into xignite_securty.symbol column
    Column("symbol",
           mysql.VARCHAR(length=_FIN_SECURITY_SYMBOL_MAX_LEN,
                         **_ASCII_TEXT_KWARGS),
           ForeignKey(xigniteSecurity.c.symbol,
                      name=schemaName + "_to_security_fk",
                      onupdate="CASCADE", ondelete="CASCADE"),
           nullable=False,
           server_default=""),

    # The title for this headline
    Column("title",
           mysql.VARCHAR(length=500),
           nullable=True),

    # The date when this headline was published (or re-published by another
    # source)
    Column("local_pub_date",
           DATE,
           nullable=False),

    # The UTC offset for the local_pub_date field
    Column("utc_offset",
           FLOAT,
           autoincrement=False,
           nullable=False),

    # The UTC date/time when this press release was discovered by our agent
    Column("discovered_at",
           DATETIME,
           nullable=False),

    # The originating journal/website for this headline. NOTE: the same article
    # URL can originate from multiple sources (e.g., "Clusterstock" and
    # "Business Insider: Finance")
    Column("source",
           mysql.VARCHAR(length=MAX_UTF8_KEY_LENGTH),
           nullable=False),

    # The URL for the headline
    # NOTE: max key length in SQL is 767 bytes
    Column("url",
           mysql.VARCHAR(length=767, **_ASCII_TEXT_KWARGS),
           nullable=False),

    # JSON list that contains URLs of all images associated with this headline
    Column("image_urls",
           mysql.MEDIUMTEXT(convert_unicode=True),
           nullable=True),

    # JSON list that contains all tags associated with this headline, broken
    # down by tag groups; the original is flattened; example:
    #   [{"Companies": ["American Airlines Group Inc.", "S&P Capital IQ"]},
    #    {"Sectors": ["Finance", "Transportation"]},
    #    {"Symbols": ["DAL", "AAL"]}, {"Topics": ["Business_Finance"]}]
    # Source: xignite SecurityHeadline.Tags
    Column("tags",
           TEXT(convert_unicode=True),
           nullable=True),

    # The time taken (in seconds) to process the request on xignite servers.
    Column("proc_dur",
           FLOAT,
           nullable=False),

    # An abbreviated version(usually 2-3 paragraphs) of the full article; NULL
    # if unknown
    # Source: GetMarketNewsDetails MarketNewsItem.Summary
    Column("summary",
           mysql.TEXT(convert_unicode=True),
           nullable=True),

    # The UTC date/time when this news article was (originally) published; NULL
    # if unknown
    # Source: GetMarketNewsDetails MarketNewsItem.Time
    Column("orig_pub_time",
           DATETIME,
           nullable=True),

    # The originating journal/website for this headline; NULL if not known
    # Source: GetMarketNewsDetails MarketNewsItem.Source
    Column("orig_source",
           mysql.TEXT(convert_unicode=True),
           nullable=True),

    # The time taken (in seconds) to process the GetMarketNewsDetails request on
    # xignite servers.
    # Source: GetMarketNewsDetails MarketNewsItem.Delay
    Column("details_proc_dur",
           FLOAT,
           nullable=True),

    PrimaryKeyConstraint("symbol", "local_pub_date", "url", "source",
                         name=schemaName + "_pk"),

    Index("discovered_at_idx", "discovered_at", unique=False)
  )


  return schema



# Security (stock) Headlines from xIgnite
xigniteSecurityHeadline = _createXigniteGlobalnewsSchema(
  "xignite_security_headline", metadata)



# Security (stock) Press Releases from xIgnite
xigniteSecurityRelease = _createXigniteGlobalnewsSchema(
  "xignite_security_release", metadata)

