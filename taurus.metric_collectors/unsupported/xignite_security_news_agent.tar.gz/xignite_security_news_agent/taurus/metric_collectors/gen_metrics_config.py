#!/usr/bin/env python
# ----------------------------------------------------------------------
# Numenta Platform for Intelligent Computing (NuPIC)
# Copyright (C) 2015, Numenta, Inc.  Unless you have purchased from
# Numenta, Inc. a separate commercial license for this software code, the
# following terms and conditions apply:
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero Public License version 3 as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU Affero Public License for more details.
#
# You should have received a copy of the GNU Affero Public License
# along with this program.  If not, see http://www.gnu.org/licenses.
#
# http://numenta.org/licenses/
# ----------------------------------------------------------------------

"""
Generate content for products/taurus.metric_collectors/conf/metrics.json from
the given csv input file and output the json object to stdout. Does not
overwrite metrics.json.

The first line of the input csv file is the header with column names, expected
to contain "Symbol", "Resource" and "Twitter" column headings (possibly among
additional other columns that shall be ignored by the script). The "Twitter"
column heading is expected to be the last column heading, with the column value
containing an optional Twitter screen name preceded by the '@' char. Additional
Twitter screen names, if any, are specified one each in subsequent columns.
"""

def _addXigniteNewsVolumeMetric(metricsDict, stockSymbol):
  """ Add an xignite security news volume (security headlines + releases)
  metric to the given metrics dict for the given stock symbol
  """
  metricName = "XIGNITE.NEWS.%s.VOLUME" % (stockSymbol.upper(),)
  metricsDict[metricName] = {
    "provider": "xignite-security-news",
    "metricType": "NewsVolume",
    "metricTypeName": "News Volume",
    "modelParams": {
      "minResolution": 0.2
    }
  }

